package com.coderdot.dtos;

import lombok.Data;

import java.util.List;

@Data
public class CarDtoList {

    private List<CarDto> carDtoList;

}
