package com.coderdot;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class RentACarSpringApplication {

	public static void main(String[] args) {
		SpringApplication.run(RentACarSpringApplication.class, args);
	}

}
