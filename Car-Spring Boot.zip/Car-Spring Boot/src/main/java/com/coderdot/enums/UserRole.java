package com.coderdot.enums;

public enum UserRole {

    ADMIN,
    CUSTOMER

}
