package com.coderdot.enums;

public enum BookCarStatus {

    PENDING,
    APPROVED,
    REJECTED

}
