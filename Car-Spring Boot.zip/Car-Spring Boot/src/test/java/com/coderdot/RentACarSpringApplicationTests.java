package com.coderdot;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RentACarSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
